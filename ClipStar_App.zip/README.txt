
ClipStar - TikTok-style Android App

Steps to Run:
1. Open the project in Android Studio.
2. Connect Firebase using your account.
3. Run the app on an emulator or real device.
4. To build APK: Go to Build > Build Bundle(s) / APK(s) > Build APK.

Features included:
- Login (Gmail, Phone, Facebook)
- Profile setup (Photo, Bio, Password)
- Auto-play Home Feed (For You / Following)
- Upload video from gallery
- AI Assistant (GPT-4o ready)
- Dummy Accounts (1000+ auto-poster)
- Watermarked downloads
- Paid Blue Tick (PKR 800/month)
